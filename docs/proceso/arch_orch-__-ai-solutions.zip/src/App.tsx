/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  LayoutDashboard, 
  Activity, 
  Database, 
  Network, 
  Settings, 
  Terminal, 
  FileText, 
  LogOut,
  ChevronRight,
  Cpu,
  Layers,
  Rocket,
  Zap,
  CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
type View = 'dashboard' | 'telemetry' | 'inventory' | 'network' | 'settings' | 'terminal';

// --- Shared Components ---

const Sidebar = ({ currentView, setView }: { currentView: View, setView: (v: View) => void }) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'telemetry', label: 'Telemetry', icon: Activity },
    { id: 'inventory', label: 'Inventory', icon: Database },
    { id: 'network', label: 'Network', icon: Network },
    { id: 'settings', label: 'Settings', icon: Settings },
  ] as const;

  return (
    <aside className="fixed left-0 top-0 h-full w-64 z-50 flex flex-col bg-base-bg border-r border-border-main">
      <div className="p-6 border-b border-border-main">
        <h2 className="text-lg font-bold text-cyber-lime font-mono tracking-tight">SYSTEM_SHELL</h2>
        <p className="technical-label mt-1">V1.0.4-STABLE</p>
      </div>
      
      <nav className="flex-1 py-4 flex flex-col gap-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            className={`flex items-center gap-4 px-6 py-3 transition-all duration-150 font-mono uppercase text-[10px] tracking-widest text-left
              ${currentView === item.id 
                ? 'bg-cyber-lime text-black border-l-4 border-white' 
                : 'text-gray-500 hover:bg-surface-container hover:text-cyber-lime border-l-4 border-transparent'
              }`}
          >
            <item.icon size={18} />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-border-main flex flex-col gap-2">
        <button 
          onClick={() => setView('terminal')}
          className="w-full bg-cyber-lime text-black font-mono font-bold uppercase text-[10px] tracking-widest py-2 hover:bg-white transition-colors flex items-center justify-center gap-2"
        >
          <Terminal size={14} /> LAUNCH_TERMINAL
        </button>
        <button className="flex items-center gap-4 text-gray-500 px-6 py-2 hover:text-cyber-lime transition-colors font-mono uppercase text-[10px] tracking-widest">
          <FileText size={16} /> Docs
        </button>
        <button className="flex items-center gap-4 text-gray-500 px-6 py-2 hover:text-cyber-lime transition-colors font-mono uppercase text-[10px] tracking-widest">
          <LogOut size={16} /> Logout
        </button>
      </div>
    </aside>
  );
};

const TopBar = () => (
  <nav className="fixed top-0 left-64 right-0 h-16 z-40 flex justify-between items-center px-8 bg-base-bg border-b border-border-main bg-noise">
    <div className="text-sm font-black tracking-[0.2em] text-cyber-lime font-mono">
      OLIVER CASTELBLANCO // ARCH_ORCH
    </div>
    <div className="flex items-center gap-4 text-gray-500">
      <button className="hover:text-cyber-lime p-2 transition-colors cursor-crosshair">
        <Terminal size={18} />
      </button>
      <button className="hover:text-cyber-lime p-2 transition-colors cursor-crosshair">
        <Network size={18} />
      </button>
    </div>
  </nav>
);

const Footer = ({ accent = "cyber-lime" }: { accent?: "cyber-lime" | "electric-cyan" }) => (
  <footer className="mt-auto border-t border-border-main px-8 py-6 flex justify-between items-center bg-base-bg font-mono">
    <div className={`text-[10px] uppercase font-black tracking-widest ${accent === 'cyber-lime' ? 'text-cyber-lime' : 'text-electric-cyan'}`}>
      © 2024 SOLUTIONS_ARCHITECT. ALL RIGHTS RESERVED.
    </div>
    <div className="hidden md:flex gap-6 text-[10px] uppercase tracking-widest text-zinc-600">
      <span className="hover:text-electric-cyan cursor-crosshair">latency: 12ms</span>
      <span className="hover:text-electric-cyan cursor-crosshair">uptime: 99.99%</span>
      <span className="hover:text-electric-cyan cursor-crosshair">encryption: aes-256</span>
      <a href="#" className="hover:text-cyber-lime">Github</a>
    </div>
    {accent === 'electric-cyan' && <div className="text-electric-cyan font-black text-[10px] tracking-widest">ARCH_ORCH</div>}
  </footer>
);

// --- View Components ---

const DashboardContent = () => {
  const directives = [
    { title: "Cloud Architecture", desc: "Distributed node deployment prioritizing zero-downtime and elastic compute scaling.", metric: "LATENCY: <5MS", icon: Network, color: "text-electric-cyan" },
    { title: "AI Orchestration", desc: "Synchronized machine learning pipelines with deterministic execution models.", metric: "SYNC: ACTIVE", icon: Layers, color: "text-cyber-lime" },
    { title: "LLM Deployment", desc: "Secure, private-instance hosting for large language models with hardware acceleration.", metric: "VRAM: OPTIMIZED", icon: Cpu, color: "text-electric-cyan" },
    { title: "Systems Optimization", desc: "Algorithmic refactoring to minimize overhead and maximize raw computational output.", metric: "EFFICIENCY: 99.9%", icon: Zap, color: "text-cyber-lime" },
  ];

  return (
    <div className="flex-1 flex flex-col gap-12 p-12 max-w-7xl mx-auto w-full pt-28">
      {/* Hero */}
      <section className="sharp-container p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative overflow-hidden">
        <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-electric-cyan m-2"></div>
        <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-border-main m-2"></div>
        
        <div className="lg:col-span-12 xl:col-span-7 flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <span className="font-mono text-[10px] uppercase text-electric-cyan bg-black/50 px-2 py-1 border border-electric-cyan/30 w-fit">Init Sequence: 0x8F2A</span>
            <h1 className="font-mono text-5xl font-bold uppercase leading-tight tracking-tighter">
              ARCH_ORCH //<br/>
              <span className="text-gray-500">AI SOLUTIONS</span>
            </h1>
          </div>
          <p className="text-lg text-gray-400 border-l-2 border-electric-cyan pl-6 font-medium">
            Architecting the future of intelligence. We deploy high-performance, modular infrastructure designed for rigorous computational demands and seamless AI orchestration.
          </p>
          <div className="flex gap-4">
            <button className="bg-cyber-lime text-black font-mono text-xs font-bold uppercase px-8 py-3 hover:bg-white transition-colors">Deploy System</button>
            <button className="border border-electric-cyan text-electric-cyan font-mono text-xs font-bold uppercase px-8 py-3 hover:bg-electric-cyan hover:text-black transition-colors">Documentation</button>
          </div>
        </div>
        
        <div className="lg:col-span-12 xl:col-span-5 h-[350px] sharp-container flex items-center justify-center relative group overflow-hidden">
          <div className="technical-label absolute top-4 left-4 z-10">SYS.IMG.01</div>
          <div className="absolute inset-0 bg-electric-cyan/10 mix-blend-overlay group-hover:bg-electric-cyan/20 transition-colors"></div>
          <img 
            src="https://images.unsplash.com/photo-1639322537228-f710d846310a?q=80&w=2000" 
            alt="Technical Architecture" 
            className="w-full h-full object-cover grayscale opacity-80 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-500 cursor-crosshair"
          />
        </div>
      </section>

      {/* Core Directives */}
      <section className="flex flex-col gap-6">
        <div className="flex justify-between items-end border-b border-border-main pb-2">
           <h2 className="font-mono text-3xl font-bold uppercase tracking-tighter">Core Directives</h2>
           <span className="technical-label">MOD: 04 // ACTIVE</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {directives.map((d, i) => (
            <article key={i} className="sharp-container p-6 bg-surface-container/50 hover:border-cyber-lime transition-colors group relative flex flex-col gap-4">
              <div className="absolute top-2 right-2 w-1 h-1 bg-border-main group-hover:bg-cyber-lime"></div>
              <d.icon className={`${d.color}`} size={32} />
              <div className="mt-auto flex flex-col gap-2">
                <h3 className="font-mono text-xl font-bold tracking-tight">{d.title}</h3>
                <p className="text-sm text-gray-500 font-medium">{d.desc}</p>
              </div>
              <div className="technical-label pt-2 border-t border-border-main mt-2 opacity-60">
                {d.metric}
              </div>
            </article>
          ))}
        </div>
      </section>
      <Footer />
    </div>
  );
};

const TelemetryContent = () => {
  return (
    <div className="flex-1 flex flex-col gap-12 p-12 max-w-7xl mx-auto w-full pt-28">
      <header className="border-b border-border-main pb-4">
        <div className="inline-block border border-electric-cyan text-electric-cyan px-2 py-1 font-mono text-[10px] mb-4">SRV_ID: AI_ORCH_01</div>
        <h1 className="font-mono text-5xl font-bold tracking-tighter uppercase mb-4 text-white">AI Orchestration Pipeline</h1>
        <p className="text-lg text-gray-400 max-w-3xl font-medium leading-relaxed">
          Advanced workflow management for multi-model AI environments. Ensuring seamless data flow, distributed execution, and real-time inference optimization.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Flow */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          <h2 className="font-mono text-2xl font-bold border-b border-border-main pb-2">Execution Flow</h2>
          <div className="flex flex-col gap-8 relative px-4 py-8 sharp-container grid-bg">
            <div className="flex items-start gap-4 p-4 sharp-container bg-surface-dim group hover:border-cyber-lime transition-colors z-10">
              <div className="p-2 border border-border-main"><Activity className="text-cyber-lime" size={24} /></div>
              <div>
                <p className="technical-label text-cyber-lime">Node_01</p>
                <h3 className="font-mono font-bold">Ingestion Engine</h3>
                <p className="text-[10px] text-gray-500 mt-1 uppercase font-mono">Stream: KAFKA_REALTIME</p>
              </div>
            </div>
            <div className="w-[1px] h-8 bg-border-main self-center -my-8"></div>
            <div className="flex items-start gap-4 p-4 sharp-container bg-surface-dim group hover:border-electric-cyan transition-colors z-10">
              <div className="p-2 border border-border-main"><Layers className="text-electric-cyan" size={24} /></div>
              <div>
                <p className="technical-label text-electric-cyan">Node_02</p>
                <h3 className="font-mono font-bold">Routing & Batching</h3>
                <p className="text-[10px] text-gray-500 mt-1 uppercase font-mono">Status: OPTIMIZED</p>
              </div>
            </div>
            <div className="w-[1px] h-8 bg-border-main self-center -my-8"></div>
            <div className="flex items-start gap-4 p-4 sharp-container bg-surface-dim group hover:border-cyber-lime transition-colors z-10">
              <div className="p-2 border border-border-main"><Cpu className="text-cyber-lime" size={24} /></div>
              <div>
                <p className="technical-label text-cyber-lime">Node_03</p>
                <h3 className="font-mono font-bold">Inference Engine</h3>
                <p className="text-[10px] text-gray-500 mt-1 uppercase font-mono">Target: GPU_CLUSTER_A</p>
              </div>
            </div>
          </div>
        </div>

        {/* Metrics */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          <h2 className="font-mono text-2xl font-bold border-b border-border-main pb-2">Performance Metrics</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sharp-container p-6 bg-surface-container flex flex-col gap-2 relative group overflow-hidden">
              <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyber-lime m-1 opacity-50"></div>
              <p className="technical-label">Latency</p>
              <div className="font-mono text-4xl font-bold text-cyber-lime flex items-center gap-2"><Zap size={24} /> 12ms</div>
              <p className="text-[10px] uppercase text-gray-500 font-mono mt-4 pt-4 border-t border-border-main">Avg P99 Response Time</p>
            </div>
            <div className="sharp-container p-6 bg-surface-container flex flex-col gap-2 relative group overflow-hidden">
               <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-electric-cyan m-1 opacity-50"></div>
              <p className="technical-label">Throughput</p>
              <div className="font-mono text-4xl font-bold text-electric-cyan flex items-center gap-2"><Activity size={24} /> 45k</div>
              <p className="text-[10px] uppercase text-gray-500 font-mono mt-4 pt-4 border-t border-border-main">Req/sec per cluster</p>
            </div>
            <div className="sharp-container p-6 bg-surface-container flex flex-col gap-2 relative group overflow-hidden">
               <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyber-lime m-1 opacity-50"></div>
              <p className="technical-label">Uptime</p>
              <div className="font-mono text-4xl font-bold text-cyber-lime flex items-center gap-2"><CheckCircle2 size={24} /> 99.9%</div>
              <p className="text-[10px] uppercase text-gray-500 font-mono mt-4 pt-4 border-t border-border-main">SLA Guaranteed</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
            <div className="sharp-container p-6 bg-surface-dim flex flex-col gap-4">
              <h3 className="font-mono font-bold flex items-center gap-2 text-electric-cyan uppercase text-sm border-b border-border-main pb-2">
                <Layers size={14} /> Technical Stack
              </h3>
              <div className="flex flex-col gap-2 font-mono text-xs text-gray-400">
                <div className="flex justify-between"><span>Compute</span> <span className="text-white">Kubernetes / Ray</span></div>
                <div className="flex justify-between"><span>Message Broker</span> <span className="text-white">Apache Kafka</span></div>
                <div className="flex justify-between"><span>Model Serving</span> <span className="text-white">Triton / vLLM</span></div>
                <div className="flex justify-between"><span>Registry</span> <span className="text-white">Prometheus / Grafana</span></div>
              </div>
            </div>
            <div className="sharp-container p-6 bg-surface-dim grid-bg flex flex-col gap-4">
              <h3 className="font-mono font-bold flex items-center gap-2 text-cyber-lime uppercase text-sm border-b border-border-main pb-2">
                <Rocket size={14} /> Deployment
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed font-medium">
                Zero-downtime deployment process utilizing canary releases and shadow traffic testing for all production nodes.
              </p>
              <button className="bg-cyber-lime text-black font-mono text-[10px] font-bold uppercase py-2 px-4 w-fit hover:bg-white transition-colors">Initialize Deployment</button>
            </div>
          </div>
        </div>
      </div>
      <Footer accent="electric-cyan" />
    </div>
  );
};

const InventoryContent = () => {
    const projects = [
        { id: "CDN", metric: "OPEX: $0.50/mo", title: "Global Edge CDN", desc: "Serverless architecture deployed across 42 regions.", color: "border-cyber-lime" },
        { id: "ML", metric: "LATENCY: 12MS", title: "Auto-Scaling ML Pipeline", desc: "Real-time inference with sub-20ms p99 latency.", color: "border-electric-cyan" },
        { id: "LEDGER", metric: "UPTIME: 99.99%", title: "Distributed Ledger Core", desc: "High-throughput financial transaction processing.", color: "border-cyber-lime" },
        { id: "IOT", metric: "1.2M RPS", title: "IoT Ingestion Gateway", desc: "Massive scale event processing architecture.", color: "border-red-500" },
        { id: "K8S", metric: "COMPUTE: -40%", title: "K8s Cluster Opt", desc: "Resource allocation overhaul and right-sizing.", color: "border-cyber-lime" },
        { id: "MESH", metric: "0-DAY: MITIGATED", title: "Zero-Trust Mesh", desc: "Implementation of mTLS across all microservices.", color: "border-electric-cyan" },
    ];

    return (
        <div className="flex-1 flex flex-col gap-12 p-12 max-w-7xl mx-auto w-full pt-28">
            <header className="border-b border-border-main pb-4 flex justify-between items-end">
                <div>
                   <h1 className="font-mono text-5xl font-bold tracking-tighter uppercase mb-2">Projects_Registry</h1>
                   <p className="technical-label text-gray-400">Metric-first architectural deployments // status: online</p>
                </div>
                <div className="font-mono text-[10px] uppercase tracking-widest text-cyber-lime border border-cyber-lime px-3 py-1">Active_Nodes: 12</div>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {projects.map((p, i) => (
                    <article key={i} className="sharp-container p-6 flex flex-col md:flex-row gap-8 items-start md:items-center bg-surface-container/30 hover:bg-surface-container/50 transition-all cursor-pointer group">
                        <div className={`border-l-2 ${p.color} pl-4 flex-1`}>
                            <p className="technical-label mb-1">Performance Metric</p>
                            <h2 className="font-mono text-2xl font-extrabold uppercase">{p.metric}</h2>
                        </div>
                        <div className="flex flex-1 justify-between items-center w-full">
                            <div>
                                <h3 className="font-mono font-bold text-lg">{p.title}</h3>
                                <p className="text-xs text-gray-500">{p.desc}</p>
                            </div>
                            <button className="p-3 border border-border-main group-hover:border-cyber-lime group-hover:text-cyber-lime transition-colors">
                                <Network size={20} />
                            </button>
                        </div>
                    </article>
                ))}
            </div>
            <Footer />
        </div>
    );
};

const NetworkContent = () => {
    const logs = [
        { id: "NET_OP_01", title: "Global Node Optimization", desc: "Restructured backbone routing protocols to minimize cross-continental packet latency.", tags: ["ROUTING", "LATENCY_OPT"], img: "https://images.unsplash.com/photo-1558494949-ef010cbdcc51?q=80&w=2000" },
        { id: "SEC_ARCH_04", title: "Zero-Trust Matrix", desc: "Complete overhaul of internal authentication protocols with hardware-level cryptographic keys.", tags: ["CRYPTOGRAPHY", "ZERO_TRUST"], img: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2000" },
        { id: "DATA_PIPE_9", title: "Telemetry Ingestion Scale", desc: "Engineered a brutalist approach to log management stripped of middleware layers.", tags: ["INGESTION", "SCALING"], img: "https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=2000" },
    ];

    return (
        <div className="flex-1 flex flex-col gap-12 p-12 max-w-7xl mx-auto w-full pt-28">
            <header className="border-b border-border-main pb-4 flex justify-between items-end">
                <div>
                   <h1 className="font-mono text-5xl font-bold tracking-tighter uppercase mb-2">Deployment_Logs</h1>
                   <p className="technical-label text-gray-400">Archive :: Technical infrastructure reviews</p>
                </div>
                <div className="technical-label text-zinc-600 hidden sm:block">RECORDS: 03 | STATUS: VERIFIED</div>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {logs.map((log) => (
                    <article key={log.id} className="sharp-container p-4 flex flex-col group hover:border-cyber-lime transition-colors bg-surface-dim">
                        <div className="relative h-48 sharp-container mb-4 overflow-hidden">
                            <div className="absolute top-2 left-2 bg-black/80 px-2 py-1 border border-border-main z-10 text-[10px] uppercase font-mono text-electric-cyan">{log.id}</div>
                            <img src={log.img} className="w-full h-full object-cover grayscale opacity-60 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-300" alt={log.id} />
                        </div>
                        <div className="flex gap-2 mb-4">
                            {log.tags.map(t => (
                                <span key={t} className="text-[9px] font-mono border border-border-main px-2 py-1 text-gray-500 uppercase">{t}</span>
                            ))}
                        </div>
                        <h3 className="font-mono font-bold text-xl mb-2">{log.title}</h3>
                        <p className="text-sm text-gray-500 flex-grow leading-relaxed">{log.desc}</p>
                        <button className="mt-6 w-full bg-cyber-lime text-black font-mono font-bold text-[10px] uppercase py-3 hover:bg-white transition-colors">Run_Diagnostic</button>
                    </article>
                ))}
            </div>
            <Footer />
        </div>
    );
};

const TerminalView = () => {
  return (
    <div className="flex-1 flex flex-col gap-12 p-12 max-w-5xl mx-auto w-full pt-28">
      <div className="sharp-container bg-black shadow-2xl relative overflow-hidden h-[700px] flex flex-col">
        {/* Terminal Header */}
        <div className="border-b border-border-main bg-surface-container px-4 py-2 flex justify-between items-center">
          <div className="flex items-center gap-2 font-mono text-[10px] text-gray-400">
            <Terminal size={14} />
            <span>usr@ocastelblanco.com: /var/www/contact</span>
          </div>
          <div className="flex gap-2">
            <div className="w-3 h-3 border border-border-main hover:bg-electric-cyan transition-colors cursor-pointer"></div>
            <div className="w-3 h-3 border border-border-main hover:bg-cyber-lime transition-colors cursor-pointer"></div>
            <div className="w-3 h-3 border border-border-main hover:bg-red-500 transition-colors cursor-pointer"></div>
          </div>
        </div>

        {/* Terminal Body */}
        <div className="flex-1 p-8 font-mono text-xs overflow-y-auto terminal-text bg-noise">
           <div className="mb-6 opacity-60">
             <p>&gt; ARCH_ORCH TERMINAL EMULATOR V.3.1.4</p>
             <p>&gt; INITIALIZING SECURE CONNECTION...</p>
             <p>&gt; ESTABLISHING HANDSHAKE WITH MAIN_NODE...</p>
             <p className="text-cyber-lime">&gt; CONNECTION ESTABLISHED [LATENCY: 12MS]</p>
             <p>&gt; WAITING FOR USER INPUT...</p>
           </div>

           <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <p className="text-gray-500 leading-none">
                  <span className="text-cyber-lime">root@ocastelblanco.com</span>:~<span className="text-electric-cyan">$</span> ./set_identity --name=
                </p>
                <input className="bg-transparent border-none text-electric-cyan p-0 focus:ring-0 placeholder:text-zinc-800" placeholder="_" autoFocus />
              </div>

              <div className="flex flex-col gap-1">
                <p className="text-gray-500 leading-none">
                  <span className="text-cyber-lime">root@ocastelblanco.com</span>:~<span className="text-electric-cyan">$</span> ./set_comms --protocol=email --address=
                </p>
                <input className="bg-transparent border-none text-electric-cyan p-0 focus:ring-0 placeholder:text-zinc-800" placeholder="_" />
              </div>

              <div className="flex flex-col gap-1">
                <p className="text-gray-500 leading-none">
                  <span className="text-cyber-lime">root@ocastelblanco.com</span>:~<span className="text-electric-cyan">$</span> cat &lt;&lt; 'EOF' &gt; payload.txt
                </p>
                <textarea className="bg-transparent border-l border-zinc-800 ml-2 pl-4 border-none text-electric-cyan p-0 focus:ring-0 placeholder:text-zinc-800 h-32" placeholder="Enter command parameters or inquiry details here..." />
                <p className="text-gray-500">EOF</p>
              </div>

              <div className="mt-4">
                <p className="text-gray-500 mb-2">
                  <span className="text-cyber-lime">root@ocastelblanco.com</span>:~<span className="text-electric-cyan">$</span> ./execute_transmission.sh
                </p>
                <button className="border border-cyber-lime text-cyber-lime px-4 py-1 hover:bg-cyber-lime hover:text-black transition-colors font-bold uppercase text-[10px]">Execute</button>
              </div>
           </div>

           <div className="mt-12 h-[1em] w-2 bg-electric-cyan animate-pulse"></div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [view, setView] = React.useState<View>('dashboard');

  return (
    <div className="min-h-screen flex text-white overflow-hidden">
      <Sidebar currentView={view} setView={setView} />
      
      <div className="flex-1 flex flex-col ml-64 min-h-screen overflow-y-auto relative">
        <TopBar />
        
        <main className="flex-1 flex flex-col">
          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.15, ease: "linear" }}
              className="flex-1 flex flex-col"
            >
              {view === 'dashboard' && <DashboardContent />}
              {view === 'telemetry' && <TelemetryContent />}
              {view === 'inventory' && <InventoryContent />}
              {view === 'network' && <NetworkContent />}
              {view === 'terminal' && <TerminalView />}
              {view === 'settings' && (
                  <div className="flex-1 flex items-center justify-center p-28">
                      <div className="sharp-container p-12 flex flex-col items-center gap-6">
                          <Settings className="text-zinc-700" size={64} />
                          <h2 className="font-mono text-xl text-zinc-600 uppercase tracking-widest">Settings_Module // Offline</h2>
                          <button onClick={() => setView('dashboard')} className="border border-zinc-800 text-zinc-600 px-8 py-2 hover:border-cyber-lime hover:text-cyber-lime transition-colors">Return to HQ</button>
                      </div>
                  </div>
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        <button 
          onClick={() => setView('terminal')}
          className="fixed bottom-8 right-8 w-14 h-14 bg-cyber-lime text-black rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(204,255,0,0.4)] hover:scale-110 active:scale-95 transition-all z-[60]"
        >
          <Terminal size={24} />
        </button>
      </div>
    </div>
  );
}
